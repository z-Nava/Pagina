1. Make sure to commit it to the `dev` branch!
2. Read https://github.com/alvarotrigo/fullPage.js/wiki/Contributing-to-fullpage.js
